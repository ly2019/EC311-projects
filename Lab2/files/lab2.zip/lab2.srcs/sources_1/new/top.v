`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 01:11:56 PM
// Design Name: 
// Module Name: top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//a top module to connect everything
module top(
    input        clk,      
    input [12:0] sw,         // switches 12..0
    output       led,        // LED for carry-out
    output [6:0] seg,         // segment pins {g,f,e,d,c,b,a}
    output [3:0] an,          // digit-enable pins
    output       dp           // decimal point
);
  
    // 1. Split the switches into three 4-bit numbers and carryin
    wire [3:0] opt = sw[12:9];   // leftmost 4 switches
    wire [3:0] a   = sw[8:5];
    wire [3:0] b   = sw[4:1];    
    wire       c_in = sw[0];     // rightmost is cin


    // 2. Wires to carry the ALU's results
    wire [3:0] out;
    wire       cout;

    // 3. The ALU
    ALU alu(.a(a), .b(b), .opt(opt), .c_in(c_in),.out(out), .cout(cout));

    // 4. The display: opcode, a, b, out (left to right)
    display disp(.clk(clk),.d3(opt), .d2(a), .d1(b), .d0(out),.an(an), .seg(seg));

    //5. led output
    assign led = cout;   // carry-out on LED X

    //6. turn decimal off
    assign dp = 1'b1;   // 1 = off because we don't need the decimal point

endmodule


`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 01:15:36 PM
// Design Name: 
// Module Name: display
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


//The display module
module display(
    input        clk,              
    input  [3:0] d3, d2, d1, d0,   // four 4-bit number
    output reg [3:0] an,           // which digit is on (active-low)
    output [6:0] seg               // segment pattern {g,f,e,d,c,b,a} (active-low)
);

    // set a counter
    reg [19:0] counter = 0;
    always @(posedge clk)
        counter <= counter + 1;

    // use the top 2 bits of counter to pick one digit out of four to display
    reg [3:0] number;                 // which number to show on the display (4 digit lights)
    always @(*) begin
        case (counter[19:18])
            2'd0: begin number = d0; an = 4'b1110; end   // rightmost digit
            2'd1: begin number = d1; an = 4'b1101; end
            2'd2: begin number = d2; an = 4'b1011; end
            default: begin number = d3; an = 4'b0111; end // leftmost digit
        endcase
    end

    // use decoder turn the chosen number into a segment pattern
    decoder dec(.hex(number), .seg(seg));

endmodule

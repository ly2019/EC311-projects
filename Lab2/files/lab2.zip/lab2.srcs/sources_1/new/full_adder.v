`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 01:22:13 PM
// Design Name: 
// Module Name: full_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


//Full adder
module full_adder(
  input cin,
  input a,
  input b,
  output sum,
  output cout);

  wire w1, w2, w3;
  assign w1	= a ^ b;
  assign w2	= a & b;
  assign w3 = cin & w1;
  assign sum = cin ^ w1;
  assign cout = w2 | w3;
endmodule

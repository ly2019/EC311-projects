`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 01:20:51 PM
// Design Name: 
// Module Name: ripple_carry_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

//2-bit Ripple adder
module ripple_carry_adder(
  input cin,
  input [1:0] a,
  input [1:0] b,
  output [1:0] sum,
  output cout);

  wire c1;
  full_adder add0(.cin(cin),.a(a[0]),.b(b[0]),.sum(sum[0]),.cout(c1));
  full_adder add1(.cin(c1),.a(a[1]),.b(b[1]),.sum(sum[1]),.cout(cout));
endmodule

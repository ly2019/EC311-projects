`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 01:18:35 PM
// Design Name: 
// Module Name: ALU
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


//the ALU module
module ALU(
  input [3:0] a,
  input [3:0] b,
  input [3:0] opt,
  input c_in,
  output [3:0] out,
  output cout
);
  
  //make the input selection for ain, bin and mode
  wire [3:0] ain = (opt == 4'b1101) ? b  :   // a is b for opt 1101 b-a
                                    a;    // keep a
  wire [3:0] bin = (opt == 4'b1101) ? a  :   // b is a for opt 1101 b-a
                  (opt == 4'b1110 | opt == 4'b1111) ? 1: // b is 1
                                    b;    // keep b as is
  wire mode = (opt == 4'b1011 | opt == 4'b1101 |opt == 4'b1111)? 1: //mode is subtraction
                                    0; //otherwise addition
  wire [3:0] out_carry_select;
  wire carry_out;

  // If set to 1110, have addition work by locking c_in to 0
  wire adder_cin = (opt == 4'b1110) ? 1'b0 : c_in;

  carry_select_adder calculate(
    .c_in(adder_cin),
    .a(ain),
    .b(bin),
    .mode(mode),
    .sum(out_carry_select),
    .cout(carry_out));
  
  //assign a value to an indicator for cases where there is a carryout
  wire use_carry_select = (opt == 4'b1010) || (opt == 4'b1011) || (opt == 4'b1101) || (opt == 4'b1110) || (opt == 4'b1111);
  assign cout = use_carry_select ? carry_out: 1'b0;

  assign out = (opt == 4'b0000)? a & b:
    (opt == 4'b0001)? a | b:
    (opt == 4'b0010) ? ~ (a & b):
    (opt == 4'b0011)? ~ (a | b):
    (opt == 4'b0100)? (a ^ b):
    (opt == 4'b0101)? ~ (a ^ b):
    (opt == 4'b0110)? ~ a:
    (opt == 4'b0111)? ~ b:
    (opt == 4'b1000)? - a: 
    (opt == 4'b1001)? - b:
    (opt == 4'b1010)? out_carry_select:  //a+b
    (opt == 4'b1011)? out_carry_select:// a-b
    (opt == 4'b1100)? a * b:
    (opt == 4'b1101)? out_carry_select://b-a
    (opt == 4'b1110)? out_carry_select://a + 1
                      out_carry_select; //a - 1

    
endmodule



`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 01:19:35 PM
// Design Name: 
// Module Name: carry_select_adder
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


//carry_select_adder inside module; only for addition and subtraction

module carry_select_adder(
  input [3:0] a,
  input [3:0] b,
  input mode,
  input c_in,
  output [3:0] sum,
  output cout
);
  wire carry_select, cout_0, cout_1;
  wire [1:0] sum_high_cin0, sum_high_cin1;
  wire [3:0] bin = (mode == 1'b0) ? b  :   // ADD: b unchanged
                                    ~b;    // SUB: b inverted

  wire cin    = (mode == 1'b0) ? c_in :       // ADD: original c_in 
                                 1'b1;       // SUB: cin is 1

  ripple_carry_adder operation_low(.cin(cin),.a(a[1:0]),.b(bin[1:0]),.sum(sum[1:0]), .cout(carry_select));
  ripple_carry_adder operation_high_cin0(.cin(1'b0),.a(a[3:2]),.b(bin[3:2]),.sum(sum_high_cin0), .cout(cout_0));
  ripple_carry_adder operation_high_cin1(.cin(1'b1),.a(a[3:2]),.b(bin[3:2]),.sum(sum_high_cin1), .cout(cout_1));

  assign cout = (carry_select == 1'b0 ) ? cout_0: //if select is 0, then select cout_0
                                    cout_1; // otherwise , select cout_1
  assign sum[3:2] = (carry_select == 1'b0 ) ? sum_high_cin0: //if select is 0, then select sum_high_cin0
                                    sum_high_cin1; // otherwise , select sum_high_cin1
endmodule
